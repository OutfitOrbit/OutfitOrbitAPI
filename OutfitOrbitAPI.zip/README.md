
### Outfit Orbit API SDL.

This repository hosts the documentation for all Outfit Orbit APIs 


#### To run the Swagger UI
Make sure you have npm installed.
    npm install
    npm start